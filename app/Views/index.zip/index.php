<!DOCTYPE html>
<html lang="zxx">

<?php
for ($i = 0; $i < count($banner); $i++) {
    $mobileImage = base_url() . $banner[$i]['mobile_img'];
    $desktopImage = base_url() . $banner[$i]['desktop_img'];
}
?>

<?php require ("components/head.php"); ?>
<style>
    .dark-scheme .card {
        background-color: rgb(255 255 255) !important;
    }

    .cart_head {
        color: #000 !important;
    }

    .cart_action .cart_wrapper,
    .cart_action .icon_cart_alt {
        color: #fff !important;
    }

    #banner_img {
        background-image: url('<?php echo $desktopImage; ?>');
        padding: 20px 0;
        background-size: cover !important;
        background-repeat: no-repeat !important;
        height: 75vh;
    }

    @media only screen and (max-width: 425px) {
        #banner_img {
            background-image: url('<?php echo $mobileImage; ?>');
        }
    }


    #banner_img {
        background-image: url('<?php echo $desktopImage; ?>');
        padding: 20px 0;
        background-size: cover !important;
        background-repeat: no-repeat !important;
        height: 75vh;
    }

    @media only screen and (max-width: 425px) {
        #banner_img {
            background-image: url('<?php echo $mobileImage; ?>');
        }
    }

    .hide-hotsale {
        display: none
    }
</style>

<body onload="initialize()" class="dark-scheme home_page-">
    <div id="wrapper">
        <?php require ("components/header.php"); ?>
        <div class="no-bottom no-top" id="content">
            <div id="top"></div>
            <section id="banner_img" class="no-top no-bottom carousel slide carousel-fade" data-mdb-ride="carousel"
                style="<?php echo base_url() ?>public/assets/images/background/banner.jpg">
                <div class=" position-relative">
                    <div class="">
                        <div class="mask">
                            <div class="no-top no-bottom">
                                <div class="h-100 v-center">
                                    <div class="container banner_container">
                                        <div class="banner_content">
                                            <h1>Two wheels,</h1>
                                            <h2>endless adventures.</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <?php
            if (session()->get('loginStatus') == "NO") {

                $hideData = "d-none";
            } else {
                $hideData = "";
            } ?>
            <section class="wishlist_section pb-0 <?php echo $hideData ?>">
                <div class="container">

                    <div class="col-lg-12 text-center newarrival_header ">
                        <h3>WISHLISTS</h3>
                        <?php
                        $wishlistdata = 2;
                        if ($wishlistdata > 2) {

                            ?>
                            <a href="<?php echo base_url() ?>newArrivalViewall">
                                <span class="view_all">View all
                                    <i class="fa fa-angle-right d-none"></i>
                                </span>
                            </a>
                            <?php
                        }
                        ?>
                    </div>
                    <div class="row d-flex justify-content-center my-4 px-3">
                        <div class="col-md-6">
                            <div class="card mb-4 order_detail">
                                <div class="card-body">
                                    <form id='product-form' method="post">
                                        <div class="row">
                                            <input type="hidden" name="table_name" id="table_name" value="" />
                                            <input type="hidden" name="prod_id" id="prod_id" value="" />
                                            <input type="hidden" name="prod_price" id="prod_price" value="" />
                                            <input type="hidden" name="quantity" id="quantity" value="" />
                                            <div class="col-lg-3 col-md-12 mb-4 mb-lg-0">
                                                <div class="bg-image hover-overlay hover-zoom ripple rounded photo"
                                                    data-mdb-ripple-color="light">
                                                    <img src="<?php base_url() ?>public/assets/images/gallery/220p2.jpg"
                                                        class="w-100 " alt="" />
                                                </div>
                                            </div>
                                            <div class="col-lg-5 col-md-6 ">
                                                <p class="product_name wish-title">
                                                    <strong>AUTOPOWERZ Abs Plastic Motorcycle Black Rear View Side
                                                        Mirror </strong>
                                                </p>
                                                <p class="d-flex wish-status">Status:
                                                    <span class="d-flex align-items-center">
                                                        <span class="product_status"></span>
                                                    </span>Available
                                                </p>
                                            </div>
                                            <div class="col-lg-4 col-md-6 wl_pricewrapper">
                                                <p class="text-md-end cart_price">
                                                    <strong>
                                                        <span class="m-0 wish-price">₹1200.00</span>
                                                    </strong>
                                                </p>
                                                <div class="cart_action">
                                                    <div class="demo-icon-wrap-s2 cart_wrapper">
                                                        <span aria-hidden="true" class="icon_cart_alt mb-0"></span>
                                                        <a type="button" class="mb-0" id='addtocart'>Add to cart</a>
                                                    </div>
                                                    <a href="#myModal" class="trigger-btn m-0" data-toggle="modal"
                                                        id="delete_cart">
                                                        <i class=" icon_trash"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Single item -->
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card mb-4 order_detail">
                                <div class="card-body">
                                    <form id='product-form' method="post">
                                        <div class="row">
                                            <input type="hidden" name="table_name" id="table_name" value="" />
                                            <input type="hidden" name="prod_id" id="prod_id" value="" />
                                            <input type="hidden" name="prod_price" id="prod_price" value="" />
                                            <input type="hidden" name="quantity" id="quantity" value="" />
                                            <div class="col-lg-3 col-md-12 mb-4 mb-lg-0">
                                                <div class="bg-image hover-overlay hover-zoom ripple rounded photo"
                                                    data-mdb-ripple-color="light">
                                                    <img src="<?php base_url() ?>public/assets/images/gallery/220p2.jpg"
                                                        class="w-100 " alt="" />
                                                </div>
                                            </div>
                                            <div class="col-lg-5 col-md-6 ">
                                                <p class="product_name wish-title">
                                                    <strong>AUTOPOWERZ Abs Plastic Motorcycle Black Rear View Side
                                                        Mirror </strong>
                                                </p>
                                                <p class="d-flex wish-status">Status:
                                                    <span class="d-flex align-items-center">
                                                        <span class="product_status"></span>
                                                    </span>Available
                                                </p>
                                            </div>
                                            <div class="col-lg-4 col-md-6 wl_pricewrapper">
                                                <p class="text-md-end cart_price">
                                                    <strong>
                                                        <span class="m-0 wish-price">₹1200.00</span>
                                                    </strong>
                                                </p>
                                                <div class="cart_action">
                                                    <div class="demo-icon-wrap-s2 cart_wrapper">
                                                        <span aria-hidden="true" class="icon_cart_alt mb-0"></span>
                                                        <a type="button" class="mb-0" id='addtocart'>Add to cart</a>
                                                    </div>
                                                    <a href="#myModal" class="trigger-btn m-0" data-toggle="modal"
                                                        id="delete_cart">
                                                        <i class=" icon_trash"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Single item -->
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section id="section-offers" class="offer_sec pt-0">
                <div class="container">
                    <div class="row g-4 align-items-center">
                        <div class="col-md-4 col-4 offer_product">
                            <a href="#">
                                <div class="de-image-text">
                                    <div class="d-text">
                                        <div class="d-quote id-color"><i class="fa fa-quote-right"></i></div>

                                    </div>
                                    <img src="<?php echo base_url() ?>public/assets/images/offers/offer1.webp"
                                        class="img-fluid" alt="">
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 col-4 offer_product">
                            <a href="#">
                                <div class="de-image-text">
                                    <div class="d-text">
                                        <div class="d-quote id-color"><i class="fa fa-quote-right"></i></div>

                                    </div>
                                    <img src="<?php echo base_url() ?>public/assets/images/offers/bag.webp"
                                        class="img-fluid" alt="">
                                </div>
                            </a>
                        </div>

                        <div class="col-md-4 col-4 offer_product">
                            <a href="#">
                                <div class="de-image-text">
                                    <div class="d-text">
                                        <div class="d-quote id-color"><i class="fa fa-quote-right"></i></div>

                                    </div>
                                    <img src="<?php echo base_url() ?>public/assets/images/offers/offer2.webp"
                                        class="img-fluid" alt="">
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </section>

            <!-- New Arrivals Start  -->
            <section id="section-newArrival" class="p-0">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12 text-center newarrival_header">
                            <h3>NEW ARRIVALS</h3>
                            <a href="<?php echo base_url() ?>newrrival-view"><span class="view_all">View all<i
                                        class="fa fa-angle-right d-none"></i></span></a>
                            <!-- <span class="view_all">View all<i class="fa fa-angle-right d-none"></i></span>  -->
                        </div>
                        <div class="col-12 col-carousel">
                            <div class="owl-carousel carousel-main">
                                <?php for ($i = 0; $i < 8; $i++) { ?>
                                    <div class="">
                                        <div class="item">
                                            <div class="">
                                                <?php
                                                $tbl_name = $new_arrivals[$i]['tbl_name'];

                                                if ($tbl_name == "tbl_products") {
                                                    $url = base_url() . "detail/" . strtolower(str_replace(' ', '-', $new_arrivals[$i]['redirect_url'])) . "/" . base64_encode($new_arrivals[$i]['prod_id']);
                                                } else if ($tbl_name == "tbl_accessories_list") {
                                                    $url = base_url() . "accessories-detail/" . strtolower(str_replace(' ', '-', $new_arrivals[$i]['redirect_url'])) . "/" . base64_encode($new_arrivals[$i]['prod_id']);
                                                } else if ($tbl_name == "tbl_rproduct_list") {
                                                    $url = base_url() . "riding-details/" . strtolower(str_replace(' ', '-', $new_arrivals[$i]['redirect_url'])) . "/" . base64_encode($new_arrivals[$i]['prod_id']);
                                                } else if ($tbl_name == "tbl_helmet_products") {
                                                    $url = base_url() . "helmet-details/" . strtolower(str_replace(' ', '-', $new_arrivals[$i]['redirect_url'])) . "/" . base64_encode($new_arrivals[$i]['prod_id']);
                                                } else if ($tbl_name == "tbl_luggage_products") {
                                                    $url = base_url() . "tour-detail/" . strtolower(str_replace(' ', '-', $new_arrivals[$i]['redirect_url'])) . "/" . base64_encode($new_arrivals[$i]['prod_id']);
                                                } else if ($tbl_name == "tbl_camping_products") {
                                                    $url = base_url() . "camp-details/" . strtolower(str_replace(' ', '-', $new_arrivals[$i]['redirect_url'])) . "/" . base64_encode($new_arrivals[$i]['prod_id']);
                                                }
                                                ?>
                                                <a href="<?php echo $url; ?>">
                                                    <div class="de-item">
                                                        <div class="d-img">
                                                            <img src="<?php echo base_url() ?><?php echo $new_arrivals[$i]['product_img'] ?>"
                                                                class="img-fluid" alt="">
                                                        </div>
                                                        <div class="d-info">
                                                            <div class="d-text">
                                                                <span
                                                                    class="d-price">₹<?php echo $new_arrivals[$i]['offer_price'] ?></span>
                                                                <h4><?php echo $new_arrivals[$i]['product_name'] ?></h4>
                                                                <div>
                                                                    <?php
                                                                    $tbl_name = $new_arrivals[$i]['tbl_name'];

                                                                    if ($tbl_name == "tbl_products") {
                                                                        $url = base_url() . "detail/" . strtolower(str_replace(' ', '-', $new_arrivals[$i]['redirect_url'])) . "/" . base64_encode($new_arrivals[$i]['prod_id']);
                                                                    } else if ($tbl_name == "tbl_accessories_list") {
                                                                        $url = base_url() . "accessories-detail/" . strtolower(str_replace(' ', '-', $new_arrivals[$i]['redirect_url'])) . "/" . base64_encode($new_arrivals[$i]['prod_id']);
                                                                    } else if ($tbl_name == "tbl_rproduct_list") {
                                                                        $url = base_url() . "riding-details/" . strtolower(str_replace(' ', '-', $new_arrivals[$i]['redirect_url'])) . "/" . base64_encode($new_arrivals[$i]['prod_id']);
                                                                    } else if ($tbl_name == "tbl_helmet_products") {
                                                                        $url = base_url() . "helmet-details/" . strtolower(str_replace(' ', '-', $new_arrivals[$i]['redirect_url'])) . "/" . base64_encode($new_arrivals[$i]['prod_id']);
                                                                    } else if ($tbl_name == "tbl_luggage_products") {
                                                                        $url = base_url() . "tour-detail/" . strtolower(str_replace(' ', '-', $new_arrivals[$i]['redirect_url'])) . "/" . base64_encode($new_arrivals[$i]['prod_id']);
                                                                    } else if ($tbl_name == "tbl_camping_products") {
                                                                        $url = base_url() . "camp-details/" . strtolower(str_replace(' ', '-', $new_arrivals[$i]['redirect_url'])) . "/" . base64_encode($new_arrivals[$i]['prod_id']);
                                                                    }
                                                                    ?>
                                                                    <a class="btn-main buynow_btn"
                                                                        href="<?php echo $url; ?>">Buy Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- New Arrivals Enddd  -->

            <!-- Hot Sale  Start  -->
            <?php
            if (count($hotsale) <= 0) {
                $class = "hide-hotsale";
            } else {
                $class = "";
            }

            ?>
            <section id="section-hotsale" class="p-0 <?php echo $class ?>">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12 text-center newarrival_header" class="view_all">
                            <h3>Hot Sale</h3>
                            <a href="<?php echo base_url() ?>hotsale"><span class="view_all">View all<i
                                        class="fa fa-angle-right d-none"></i></span></a>
                        </div>
                        <div class="col-12 col-carousel">
                            <div class="owl-carousel carousel-main">
                                <?php
                                for ($i = 0; $i < 8; $i++) { ?>
                                    <div class="">
                                        <div class="item">
                                            <div class="">
                                                <?php
                                                $tbl_name = $hotsale[$i]['tbl_name'];

                                                if ($tbl_name == "tbl_products") {
                                                    $url = base_url() . "detail/" . strtolower(str_replace(' ', '-', $hotsale[$i]['redirect_url'])) . "/" . base64_encode($hotsale[$i]['prod_id']);
                                                } else if ($tbl_name == "tbl_accessories_list") {
                                                    $url = base_url() . "accessories-detail/" . strtolower(str_replace(' ', '-', $hotsale[$i]['redirect_url'])) . "/" . base64_encode($hotsale[$i]['prod_id']);
                                                } else if ($tbl_name == "tbl_rproduct_list") {
                                                    $url = base_url() . "riding-details/" . strtolower(str_replace(' ', '-', $hotsale[$i]['redirect_url'])) . "/" . base64_encode($hotsale[$i]['prod_id']);
                                                } else if ($tbl_name == "tbl_helmet_products") {
                                                    $url = base_url() . "helmet-details/" . strtolower(str_replace(' ', '-', $hotsale[$i]['redirect_url'])) . "/" . base64_encode($hotsale[$i]['prod_id']);
                                                } else if ($tbl_name == "tbl_luggage_products") {
                                                    $url = base_url() . "tour-detail/" . strtolower(str_replace(' ', '-', $hotsale[$i]['redirect_url'])) . "/" . base64_encode($hotsale[$i]['prod_id']);
                                                } else if ($tbl_name == "tbl_camping_products") {
                                                    $url = base_url() . "camp-details/" . strtolower(str_replace(' ', '-', $hotsale[$i]['redirect_url'])) . "/" . base64_encode($hotsale[$i]['prod_id']);
                                                }
                                                ?>
                                                <a href="<?php echo $url; ?>">
                                                    <div class="de-item">
                                                        <div class="d-img">
                                                            <img src="<?php echo base_url() ?>/<?php echo $hotsale[$i]['product_img'] ?>"
                                                                class="img-fluid" alt="">
                                                        </div>
                                                        <div class="d-info">
                                                            <div class="d-text">
                                                                <span
                                                                    class="d-price">₹<?php echo $hotsale[$i]['offer_price'] ?></span>
                                                                <h4><?php echo $hotsale[$i]['product_name'] ?></h4>
                                                                <div>
                                                                    <?php
                                                                    $tbl_name = $hotsale[$i]['tbl_name'];

                                                                    if ($tbl_name == "tbl_products") {
                                                                        $url = base_url() . "detail/" . strtolower(str_replace(' ', '-', $hotsale[$i]['redirect_url'])) . "/" . base64_encode($hotsale[$i]['prod_id']);
                                                                    } else if ($tbl_name == "tbl_accessories_list") {
                                                                        $url = base_url() . "accessories-detail/" . strtolower(str_replace(' ', '-', $hotsale[$i]['redirect_url'])) . "/" . base64_encode($hotsale[$i]['prod_id']);
                                                                    } else if ($tbl_name == "tbl_rproduct_list") {
                                                                        $url = base_url() . "riding-details/" . strtolower(str_replace(' ', '-', $hotsale[$i]['redirect_url'])) . "/" . base64_encode($hotsale[$i]['prod_id']);
                                                                    } else if ($tbl_name == "tbl_helmet_products") {
                                                                        $url = base_url() . "helmet-details/" . strtolower(str_replace(' ', '-', $hotsale[$i]['redirect_url'])) . "/" . base64_encode($hotsale[$i]['prod_id']);
                                                                    } else if ($tbl_name == "tbl_luggage_products") {
                                                                        $url = base_url() . "tour-detail/" . strtolower(str_replace(' ', '-', $hotsale[$i]['redirect_url'])) . "/" . base64_encode($hotsale[$i]['prod_id']);
                                                                    } else if ($tbl_name == "tbl_camping_products") {
                                                                        $url = base_url() . "camp-details/" . strtolower(str_replace(' ', '-', $hotsale[$i]['redirect_url'])) . "/" . base64_encode($hotsale[$i]['prod_id']);
                                                                    }
                                                                    ?>
                                                                    <a class="btn-main buynow_btn"
                                                                        href="<?php echo $url; ?>">Buy Now</a>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>

                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <!-- Brands We deal  Start  -->
            <section id="section-brands" class="p-0">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12 text-center newarrival_header">
                            <h3>BRANDS WE DEAL</h3>
                            <a href="<?php echo base_url() ?>brands-viewall"><span class="view_all">View all<i
                                        class="fa fa-angle-right d-none"></i></span></a>
                        </div>
                        <div class="col-12 col-carousel">
                            <div class="owl-carousel carousel-main">
                                <?php for ($i = 0; $i < count($brand); $i++) {
                                    ?>
                                    <div class="">
                                        <div class="item">
                                            <div class="">
                                                <a href="#">
                                                    <div class="de-item">
                                                        <div class="d-img">
                                                            <a
                                                                href='<?php echo base_url() ?>shopby-brand/<?php echo str_replace(' ', '-', strtolower($brand[$i]['brand_name'])) ?>'><img
                                                                    src="<?php echo base_url() ?><?php echo $brand[$i]['brand_img'] ?>"
                                                                    class="img-fluid" alt=""></a>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>

                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Brands We deal  End  -->


            <!-- Helmets  start  -->
            <section id="section-helmets" class="py-0">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-12 text-center newarrival_header">
                            <h3>HELMETS</h3>
                            <a href="<?php echo base_url() ?>helmet-view"><span class="view_all">View all<i
                                        class="fa fa-angle-right d-none"></i></span></a>
                        </div>
                        <div class="col-12 col-carousel">
                            <div class="owl-carousel carousel-main">
                                <?php for ($i = 0; $i < count($h_submenu_list); $i++) { ?>
                                    <div class="">
                                        <div class="item">
                                            <div class="">
                                                <a
                                                    href="<?php echo base_url() ?>helmet-accessories/<?php echo strtolower(str_replace(' ', '-', $h_submenu[$i]['h_submenu'])) ?>/<?php echo base64_encode($h_submenu[$i]['h_submenu_id']) ?>">
                                                    <div class="de-item">
                                                        <div class="d-img">
                                                            <img src="<?php echo base_url() ?><?php echo $h_submenu_list[$i]['hsubmenu_img'] ?>"
                                                                class="img-fluid" alt="">
                                                        </div>
                                                        <div class="d-info">
                                                            <div class="d-text">
                                                                <h4 class="text-center">
                                                                    <?php echo $h_submenu_list[$i]['h_submenu'] ?>
                                                                </h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Helmets  End  -->

            <!-- SOCIAL MEDIA start -->
            <section id="social_media" class="pt-0">
                <div class="container p-0">
                    <div class="row">
                        <div class="col-lg-12 text-center newarrival_header">
                            <h3>SOCIAL MEDIA</h3>
                        </div>

                        <div class="col-4 left_container">
                            <a href="<?php echo $youtube[0]['ytube_link'] ?>">
                                <img src="<?php echo base_url() ?>/<?php echo $youtube[0]['ytube_img'] ?>"
                                    class="img-fluid img-left" alt="">
                                <i><img src="<?php echo base_url() ?>public/assets/images/icons/bi_youtube.png"
                                        alt=""></i>
                            </a>
                        </div>


                        <div class="col-4 center_container">
                            <a href="<?php echo $youtube[1]['ytube_link'] ?>">
                                <img src="<?php echo base_url() ?>/<?php echo $youtube[1]['ytube_img'] ?>"
                                    class="img-fluid img-center" alt="">
                                <i><img src="<?php echo base_url() ?>public/assets/images/icons/bi_youtube.png"
                                        alt=""></i>
                            </a>
                        </div>


                        <div class="col-4 right_container">
                            <a href="<?php echo $youtube[2]['ytube_link'] ?>">
                                <img src="<?php echo base_url() ?>/<?php echo $youtube[2]['ytube_img'] ?>"
                                    class="img-fluid img-right" alt="">
                                <i><img src="<?php echo base_url() ?>public/assets/images/icons/bi_youtube.png"
                                        alt=""></i>
                            </a>
                        </div>

                    </div>

                </div>
            </section>
            <!-- SOCIAL MEDIA end -->
            <!-- <section id="section_testimonial" class="pt-0">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="text-center">
                    <h3>Testimonial</h3>
                </div>
                <div class="gtco-testimonials" id="section-testimonials">
                    <div class="owl-carousel owl-carousel1 owl-theme">
                        <div>
                            <div class="card text-center">
                                <div class="card-body">
                                    <h5>Very satisfied<br /></h5>
                                    <p class="card-text">“ This brake cleaner is a very useful product which I have
                                        purchased from Adventure Shoppe. I'm very satisfied with the product and the
                                        results. Thank you for suggesting this product.”
                                    </p>
                                    <span>-Eric Churchill</span>
                                </div>

                            </div>
                        </div>
                        <div>
                            <div class="card text-center">
                                <div class="card-body">
                                    <h5>Desires color for Helmets<br />
                                    </h5>
                                    <p class="card-text">“Excellent choice for riding gear purchase, it's our 3rd
                                        purchase, overall too good lot of verity, they will arrange for desires color
                                        for helmets.”
                                    </p>
                                    <span>-Aishwarya</span>
                                </div>

                            </div>
                        </div>
                        <div>
                            <div class="card text-center">
                                <div class="card-body">
                                    <h5>Responsive and Helpful<br />
                                    </h5>
                                    <p class="card-text">“I have been using Rentaly for my Car Rental needs for over 5
                                        years now. I have never had any problems with their service. Their customer
                                        support is always responsive and helpful” </p>
                                    <span>-RanjithKumar</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section> -->


            <!-- content close -->
            <a href="#" id="back-to-top"></a>
            <?php require ("components/footer.php"); ?>
            <script>
                // (function() {
                //     "use strict";

                //     var carousels = function() {
                //         $(".owl-carousel1").owlCarousel({
                //             loop: true,
                //             center: true,
                //             margin: 10,
                //             responsiveClass: true,
                //             nav: false,
                //             responsive: {
                //                 0: {
                //                     items: 1,
                //                     nav: false
                //                 },
                //                 680: {
                //                     items: 2,
                //                     nav: false,
                //                     loop: false
                //                 },
                //                 1000: {
                //                     items: 3,
                //                     nav: true
                //                 }
                //             }
                //         });
                //     };

                //     (function($) {
                //         carousels();
                //     })(jQuery);
                // })();


                // $(document).ready(function() {
                //     $(".owl-carousel").owlCarousel({
                //         loop: true,
                //         margin: 10,
                //         nav: true,
                //         responsive: {
                //             0: {
                //                 items: 1
                //             },
                //             600: {
                //                 items: 3
                //             },
                //             1000: {
                //                 items: 4
                //             }
                //         }
                //     });
                // });
                // $(document).ready(function() {
                //     var itemsMainDiv = $('.MultiCarousel');
                //     var itemsDiv = $('.MultiCarousel-inner');
                //     var itemWidth = "";

                //     $('.leftLst, .rightLst').click(function() {
                //         var condition = $(this).hasClass("leftLst");
                //         if (condition)
                //             moveSlide(0, this);
                //         else
                //             moveSlide(1, this);
                //     });

                //     resizeCarousel();

                //     $(window).resize(function() {
                //         resizeCarousel();
                //     });

                //     function resizeCarousel() {
                //         var incno = 0;
                //         var itemClass = '.item';
                //         var id = 0;
                //         var btnParentSb = '';
                //         var itemsSplit = '';
                //         var sampwidth = itemsMainDiv.width();
                //         var bodyWidth = $('body').width();
                //         itemsDiv.each(function() {
                //             id = id + 1;
                //             var itemNumbers = $(this).find(itemClass).length;
                //             btnParentSb = $(this).parent().data("items");
                //             itemsSplit = btnParentSb.split(',');
                //             $(this).parent().attr("id", "MultiCarousel" + id);

                //             if (bodyWidth >= 1200) {
                //                 incno = itemsSplit[3];
                //                 itemWidth = sampwidth / incno;
                //             } else if (bodyWidth >= 992) {
                //                 incno = itemsSplit[2];
                //                 itemWidth = sampwidth / incno;
                //             } else if (bodyWidth >= 768) {
                //                 incno = itemsSplit[1];
                //                 itemWidth = sampwidth / incno;
                //             } else {
                //                 incno = itemsSplit[0];
                //                 itemWidth = sampwidth / incno;
                //             }
                //             $(this).css({
                //                 'transform': 'translateX(0px)',
                //                 'width': itemWidth * itemNumbers
                //             });
                //             $(this).find(itemClass).each(function() {
                //                 $(this).outerWidth(itemWidth);
                //             });

                //             $(".leftLst").addClass("over");
                //             $(".rightLst").removeClass("over");
                //         });
                //     }

                //     function moveSlide(direction, element) {
                //         var leftBtn = $('.leftLst');
                //         var rightBtn = $('.rightLst');
                //         var translateXval = '';
                //         var divStyle = $(element).parent().find(itemsDiv).css('transform');
                //         var values = divStyle.match(/-?[\d\.]+/g);
                //         var xds = values ? Math.abs(values[4]) : 0;
                //         var slideWidth = itemWidth * $(element).parent().data("slide");

                //         if (direction === 0) {
                //             translateXval = parseInt(xds) - parseInt(slideWidth);
                //             $(element).parent().find(rightBtn).removeClass("over");

                //             if (translateXval <= itemWidth / 2) {
                //                 translateXval = 0;
                //                 $(element).parent().find(leftBtn).addClass("over");
                //             }
                //         } else if (direction === 1) {
                //             var itemsCondition = $(element).parent().find(itemsDiv).width() - $(element).parent().width();
                //             translateXval = parseInt(xds) + parseInt(slideWidth);
                //             $(element).parent().find(leftBtn).removeClass("over");

                //             if (translateXval >= itemsCondition - itemWidth / 2) {
                //                 translateXval = itemsCondition;
                //                 $(element).parent().find(rightBtn).addClass("over");
                //             }
                //         }
                //         $(element).parent().find(itemsDiv).css('transform', 'translateX(' + -translateXval + 'px)');
                //     }
                // });

                // Owl Carousel

                $('.carousel-main').owlCarousel({
                    items: 4,
                    loop: true,
                    autoplay: true,
                    autoplayTimeout: 7000,
                    margin: 1,
                    nav: true,
                    dots: false,
                    responsiveClass: true,
                    responsive: {
                        0: {
                            items: 2,
                            nav: true
                        },
                        600: {
                            items: 3,
                            nav: false
                        },
                        1000: {
                            items: 4,
                            nav: true,
                            loop: true
                        }
                    }
                })
            </script>
</body>


</html>